import { Data, animate, Override, Animatable } from 'framer'
const data = Data({
  scale: Animatable(1),
  circleTop: Animatable(0),
  circleLeft: Animatable(0),
  circleScale: Animatable(1),
  circleOpacity: Animatable(0),
})

window.log = console.log

export const Button: Override = () => {
  return {
    onTap(e) {
      log('e', e)
      data.circleLeft.set(e.originalEvent.offsetX)
      data.circleTop.set(e.originalEvent.offsetY)
      data.circleScale.set(0.1)
      data.circleOpacity.set(1)

      animate.easeInOut(data.circleScale, 10)
      animate.easeInOut(data.circleOpacity, 0)
    },
    onMouseDown(e) {},
  }
}

export const Circle: Override = () => {
  return {
    top: data.circleTop,
    left: data.circleLeft,
    scale: data.circleScale,
    opacity: data.circleOpacity,
  }
}
