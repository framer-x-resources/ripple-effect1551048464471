import { Data, animate, Override, Animatable } from 'framer'
const data = Data({
  scale: Animatable(1),
  circleTop: Animatable(0),
  circleLeft: Animatable(0),
})

window.log = console.log

export const Button: Override = () => {
  return {
    // scale: data.scale,
    onTap(e) {
      // data.scale.set(0.6)
      // animate.spring(data.scale, 1)
      log('e', e)
    },
  }
}

export const Circle: Override = () => {
  return {
    top: data.circleTop,
    left: data.circleLeft,
  }
}
