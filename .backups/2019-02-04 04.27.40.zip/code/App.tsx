import { Data, animate, Override, Animatable } from 'framer'
const data = Data({
  scale: Animatable(1),
  circleTop: Animatable(0),
  circleLeft: Animatable(0),
  circleScale: Animatable(1),
  circleOpacity: Animatable(0),
})

window.log = console.log

export const Button: Override = () => {
  return {
    // scale: data.scale,
    onTap(e) {
      // data.scale.set(0.6)
      // animate.spring(data.scale, 1)
      log('e', e.point)
      data.circleLeft.set(e.point.x)
      data.circleTop.set(e.point.y)
      data.circleScale.set(0.1)
      data.circleOpacity.set(1)

      animate.easeInOut(data.circleScale, 10)
      animate.easeInOut(data.circleOpacity, 0)
    },
  }
}

export const Circle: Override = () => {
  return {
    top: data.circleTop,
    left: data.circleLeft,
    scale: data.circleScale,
    opacity: data.circleOpacity,
  }
}
